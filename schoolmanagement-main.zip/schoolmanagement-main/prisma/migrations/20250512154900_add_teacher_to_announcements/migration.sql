-- AlterTable
ALTER TABLE "Result" ADD COLUMN     "feedback" TEXT;
