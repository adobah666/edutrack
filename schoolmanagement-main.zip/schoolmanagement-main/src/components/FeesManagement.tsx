'use client';

import FormModal from "./FormModal";
import Pagination from "./Pagination";
import TableSearch from "./TableSearch";
import Image from "next/image";
import Link from "next/link";
import FeesChart from "./FeesChart";
import { toast } from "react-toastify";
import FeesFilter from "./FeesFilter";

type FeeData = {
  id: number;
  amount: number;
  dueDate: Date;
  classId: number;
  feeTypeId: number;
  className: string;
  feeTypeName: string;
  paidCount: number;
  totalStudents: number;
  totalPaid: number;
};

type FeesManagementProps = {
  data: FeeData[];
  count: number;
  classes: { id: number; name: string; }[];
  feeTypes: { id: number; name: string; }[];
  page: number;
  role?: string;
};

const FeesManagement = ({
  data,
  count,
  classes,
  feeTypes,
  page,
  role,
}: FeesManagementProps) => {
  const columns = [
    {
      header: "Fee Type",
      accessor: "feeType",
    },
    {
      header: "Class",
      accessor: "class",
    },
    {
      header: "Amount",
      accessor: "amount",
    },
    {
      header: "Due Date",
      accessor: "dueDate",
    },
    {
      header: "Status",
      accessor: "status",
    },
    {
      header: "Payments",
      accessor: "payments",
    },
    {
      header: "Actions",
      accessor: "action",
    },
  ];

  return (
    <div className="bg-white p-4 rounded-lg">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="text-2xl font-semibold text-gray-800">Fees Management</h1>
          <p className="text-gray-600 mt-1">Click &quot;View Student Payments&quot; to see individual student payment status and collect payments.</p>
        </div>        {role === "admin" && (          <div className="flex items-center gap-2">
            <FormModal table="classFee" type="create" relatedData={{ classes, feeTypes }} buttonText="Add Class Fee" />
            <FormModal table="feeType" type="create" buttonText="Add Fee Type" />
            <button
              onClick={async () => {
                try {
                  const response = await fetch('/api/fees/reminders', {
                    method: 'POST',
                    headers: {
                      'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ type: 'upcoming' }),
                  });
                  
                  if (response.ok) {
                    toast.success('Payment reminders sent successfully!');
                  } else {
                    throw new Error('Failed to send reminders');
                  }
                } catch (error) {
                  toast.error('Error sending payment reminders');
                  console.error('Error:', error);
                }
              }}
              className="flex items-center gap-1 px-3 py-2 text-sm text-white bg-lamaSky rounded-md hover:bg-blue-600"
            >
              <Image src="/mail.png" alt="" width={18} height={18} />
              <span>Send Payment Reminders</span>
            </button>
          </div>
        )}
      </div>

      <div className="flex gap-4 mb-4 flex-col sm:flex-row">
        <TableSearch placeholder="Search by fee type or class..." />
        <FeesFilter classes={classes} feeTypes={feeTypes} />
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full text-sm">
          <thead>
            <tr>
              {columns.map((column) => (
                <th
                  key={column.accessor}
                  className="border-b border-gray-200 bg-gray-50 px-5 py-3 text-left"
                >
                  {column.header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.map((fee) => (
              <tr key={fee.id} className="hover:bg-gray-50">
                <td className="border-b border-gray-200 px-5 py-3">
                  {fee.feeTypeName}
                </td>
                <td className="border-b border-gray-200 px-5 py-3">
                  {fee.className}
                </td>
                <td className="border-b border-gray-200 px-5 py-3">
                  GH₵{fee.amount.toFixed(2)}
                </td>
                <td className="border-b border-gray-200 px-5 py-3">
                  {new Date(fee.dueDate).toLocaleDateString()}
                </td>
                <td className="border-b border-gray-200 px-5 py-3">
                  {fee.paidCount}/{fee.totalStudents} students paid
                  <br />                  <span className="text-xs text-gray-500">
                    Total Paid: GH₵{Number(fee.totalPaid).toFixed(2)} of GH₵{(Number(fee.amount) * Number(fee.totalStudents)).toFixed(2)}
                  </span>
                </td>
                <td className="border-b border-gray-200 px-5 py-3">
                  {fee.paidCount} payments
                </td>
                <td className="border-b border-gray-200 px-5 py-3">
                  <div className="flex items-center gap-2">                    {role === "admin" && (
                      <>
                        <FormModal table="classFee" type="update" data={fee} relatedData={{ classes, feeTypes }} />
                        <FormModal table="classFee" type="delete" id={fee.id} />
                      </>
                    )}<Link 
                      href={`/fees/${fee.id}`}
                      className="flex items-center gap-1 bg-lamaPurple text-white px-4 py-2 rounded-md hover:bg-opacity-90"
                    >
                      <Image src="/view.png" alt="" width={20} height={20} className="invert" />
                      <span>View Student Payments</span>
                    </Link>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-8">
        <FeesChart data={data} />
      </div>

      <div className="mt-8">
        <Pagination count={count} page={page} />
      </div>
    </div>
  );
};

export default FeesManagement;
