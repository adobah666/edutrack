'use client';

import FormModal from "../FormModal";

const CreateExamButton = () => {
  return <FormModal table="exam" type="create" />;
};

export default CreateExamButton;
